const client_manifest = {
  "_Button.7a168482.js": {
    "resourceType": "script",
    "module": true,
    "file": "Button.7a168482.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ButtonsSlide.6f868bc5.js": {
    "resourceType": "script",
    "module": true,
    "file": "ButtonsSlide.6f868bc5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ScrollTrigger.c3252e56.js": {
    "resourceType": "script",
    "module": true,
    "file": "ScrollTrigger.c3252e56.js"
  },
  "_asyncData.c46b9443.js": {
    "resourceType": "script",
    "module": true,
    "file": "asyncData.c46b9443.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.a6ef77ff.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.a6ef77ff.js"
  },
  "_index.c0e8c521.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.fa40e672.css"
    ],
    "dynamicImports": [
      "components/SecondScreen.vue",
      "components/ThirdScreen.vue",
      "components/FourthScreen.vue",
      "components/FifthScreen.vue",
      "components/SixthScreen.vue",
      "components/Contacts.vue",
      "components/Footer.vue"
    ],
    "file": "index.c0e8c521.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true
  },
  "index.fa40e672.css": {
    "file": "index.fa40e672.css",
    "resourceType": "style"
  },
  "_nuxt-link.46b4b5a6.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.46b4b5a6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_preview.da95aecc.js": {
    "resourceType": "script",
    "module": true,
    "file": "preview.da95aecc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_query.2f6776e5.js": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/content/dist/runtime/composables/client-db.mjs"
    ],
    "file": "query.2f6776e5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js",
      "_utils.2ca8ce81.js"
    ]
  },
  "_utils.2ca8ce81.js": {
    "resourceType": "script",
    "module": true,
    "file": "utils.2ca8ce81.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js"
    ]
  },
  "components/Contacts.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Contacts.bcf87079.js",
    "imports": [
      "_index.c0e8c521.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Contacts.vue"
  },
  "components/FifthScreen.css": {
    "resourceType": "style",
    "file": "FifthScreen.97ba57df.css",
    "src": "components/FifthScreen.css"
  },
  "components/FifthScreen.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "FifthScreen.97ba57df.css"
    ],
    "file": "FifthScreen.b45bf346.js",
    "imports": [
      "_nuxt-link.46b4b5a6.js",
      "_query.2f6776e5.js",
      "_index.c0e8c521.js",
      "_Button.7a168482.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ScrollTrigger.c3252e56.js",
      "_preview.da95aecc.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "components/FifthScreen.vue"
  },
  "FifthScreen.97ba57df.css": {
    "file": "FifthScreen.97ba57df.css",
    "resourceType": "style"
  },
  "components/Footer.css": {
    "resourceType": "style",
    "file": "Footer.a46aedc2.css",
    "src": "components/Footer.css"
  },
  "components/Footer.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "Footer.a46aedc2.css"
    ],
    "file": "Footer.1ba1e779.js",
    "imports": [
      "_nuxt-link.46b4b5a6.js",
      "_index.c0e8c521.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Footer.vue"
  },
  "Footer.a46aedc2.css": {
    "file": "Footer.a46aedc2.css",
    "resourceType": "style"
  },
  "components/FourthScreen.css": {
    "resourceType": "style",
    "file": "FourthScreen.943ab0bd.css",
    "src": "components/FourthScreen.css"
  },
  "components/FourthScreen.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "FourthScreen.943ab0bd.css"
    ],
    "file": "FourthScreen.4f8887fc.js",
    "imports": [
      "_query.2f6776e5.js",
      "_index.c0e8c521.js",
      "_ButtonsSlide.6f868bc5.js",
      "_ScrollTrigger.c3252e56.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js",
      "_utils.2ca8ce81.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/FourthScreen.vue"
  },
  "FourthScreen.943ab0bd.css": {
    "file": "FourthScreen.943ab0bd.css",
    "resourceType": "style"
  },
  "components/SecondScreen.css": {
    "resourceType": "style",
    "file": "SecondScreen.0783f999.css",
    "src": "components/SecondScreen.css"
  },
  "components/SecondScreen.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "SecondScreen.0783f999.css"
    ],
    "file": "SecondScreen.a89b92f2.js",
    "imports": [
      "_index.c0e8c521.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/SecondScreen.vue"
  },
  "SecondScreen.0783f999.css": {
    "file": "SecondScreen.0783f999.css",
    "resourceType": "style"
  },
  "components/SixthScreen.css": {
    "resourceType": "style",
    "file": "SixthScreen.a66d5213.css",
    "src": "components/SixthScreen.css"
  },
  "components/SixthScreen.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "SixthScreen.a66d5213.css"
    ],
    "file": "SixthScreen.f9de3990.js",
    "imports": [
      "_index.c0e8c521.js",
      "_Button.7a168482.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/SixthScreen.vue"
  },
  "SixthScreen.a66d5213.css": {
    "file": "SixthScreen.a66d5213.css",
    "resourceType": "style"
  },
  "components/ThirdScreen.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ThirdScreen.f374ac72.js",
    "imports": [
      "_query.2f6776e5.js",
      "_index.c0e8c521.js",
      "_ButtonsSlide.6f868bc5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js",
      "_utils.2ca8ce81.js",
      "_nuxt-link.46b4b5a6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/ThirdScreen.vue"
  },
  "index.css": {
    "resourceType": "style",
    "file": "index.fa40e672.css",
    "src": "index.css"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentDoc.49c8bfca.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue",
      "_index.a6ef77ff.js",
      "_preview.da95aecc.js",
      "_asyncData.c46b9443.js",
      "_query.2f6776e5.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentList.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentList.62fb1720.js",
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.c46b9443.js",
      "_preview.da95aecc.js",
      "_query.2f6776e5.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentList.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentNavigation.vue": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/content/dist/runtime/composables/client-db.mjs"
    ],
    "file": "ContentNavigation.4d1cb61c.js",
    "imports": [
      "_asyncData.c46b9443.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js",
      "_nuxt-link.46b4b5a6.js",
      "_query.2f6776e5.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentNavigation.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentQuery.7ab062e2.js",
    "imports": [
      "_asyncData.c46b9443.js",
      "_preview.da95aecc.js",
      "_query.2f6776e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentRenderer.32476556.js",
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.a6ef77ff.js",
      "_preview.da95aecc.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentRendererMarkdown.16557000.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.a6ef77ff.js",
      "_preview.da95aecc.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ContentSlot.cc2b07ab.js",
    "imports": [
      "_utils.2ca8ce81.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.da95aecc.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenEmpty.vue": {
    "resourceType": "script",
    "module": true,
    "file": "DocumentDrivenEmpty.14a51737.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenEmpty.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenNotFound.vue": {
    "resourceType": "script",
    "module": true,
    "file": "DocumentDrivenNotFound.da8d7e6b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenNotFound.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Markdown.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Markdown.e31c4cf4.js",
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_utils.2ca8ce81.js",
      "_preview.da95aecc.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Markdown.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseA.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseA.2b595b22.js",
    "imports": [
      "_nuxt-link.46b4b5a6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseA.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseBlockquote.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseBlockquote.43c70c73.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseBlockquote.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCode.css": {
    "resourceType": "style",
    "file": "ProseCode.e63e49c6.css",
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCode.css"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCode.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "ProseCode.e63e49c6.css"
    ],
    "file": "ProseCode.39e1f8a4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCode.vue"
  },
  "ProseCode.e63e49c6.css": {
    "file": "ProseCode.e63e49c6.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCodeInline.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseCodeInline.7369ecf1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCodeInline.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseEm.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseEm.80b1d274.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseEm.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH1.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH1.92507477.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH1.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH2.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH2.3b85bed6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH2.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH3.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH3.a7a0dc7a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH3.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH4.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH4.94873a6d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH4.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH5.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH5.7fc43771.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH5.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH6.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseH6.1a746555.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseH6.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseHr.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseHr.b8b953eb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseHr.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseImg.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseImg.cf6dded8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseImg.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseLi.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseLi.1c6c121a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseLi.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseOl.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseOl.c19985a5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseOl.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseP.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseP.c2f934f3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseP.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseStrong.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseStrong.3752ecfd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseStrong.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTable.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseTable.f8d8ab14.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTable.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTbody.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseTbody.cf73fe37.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTbody.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTd.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseTd.0910d8b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTd.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTh.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseTh.835ad58e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTh.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseThead.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseThead.aeb75f1e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseThead.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTr.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseTr.b04fee1b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseTr.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseUl.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ProseUl.2fe5107f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseUl.vue"
  },
  "node_modules/@nuxt/content/dist/runtime/composables/client-db.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "client-db.5678ab23.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_query.2f6776e5.js",
      "_index.a6ef77ff.js",
      "_preview.da95aecc.js",
      "_utils.2ca8ce81.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/content/dist/runtime/composables/client-db.mjs"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.7fc72018.css"
    ],
    "file": "error-404.b44f735d.js",
    "imports": [
      "_nuxt-link.46b4b5a6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.c5df6088.css"
    ],
    "file": "error-500.e67fadd8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.14c230b1.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.14c230b1.css"
    ],
    "dynamicImports": [
      "_index.c0e8c521.js",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.f9e64c94.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.14c230b1.css": {
    "file": "entry.14c230b1.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
