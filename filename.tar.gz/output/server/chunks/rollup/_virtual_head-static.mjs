const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>9am agency</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\">\n<meta name=\"description\" content=\"9am agency. Video Production.\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"/favicon.svg\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
