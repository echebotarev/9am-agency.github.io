import{_ as o,o as r,c as s,S as t}from"./entry.f9e64c94.js";const c={};function n(e,a){return r(),s("li",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
