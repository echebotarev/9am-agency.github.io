import{_ as r,o,c as t,S as s}from"./entry.f9e64c94.js";const c={};function n(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
