import{g as n,H as e}from"./entry.f9e64c94.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
