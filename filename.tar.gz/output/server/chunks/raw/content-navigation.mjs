// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Content\",\"_path\":\"/content\"}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
