import{_ as o,o as r,c as t,S as n}from"./entry.f9e64c94.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
