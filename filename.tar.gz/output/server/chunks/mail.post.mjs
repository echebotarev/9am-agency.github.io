import { defineEventHandler, readBody } from 'h3';
import nodemailer from 'nodemailer';
import { u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'unstorage/drivers/overlay';
import 'unstorage/drivers/memory';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unified';
import 'mdast-util-to-string';
import 'micromark/lib/preprocess.js';
import 'micromark/lib/postprocess.js';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'remark-emoji';
import 'rehype-slug';
import 'remark-squeeze-paragraphs';
import 'rehype-external-links';
import 'remark-gfm';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'remark-mdc';
import 'remark-parse';
import 'remark-rehype';
import 'mdast-util-to-hast';
import 'detab';
import 'unist-builder';
import 'mdurl';
import 'slugify';
import 'unist-util-position';
import 'unist-util-visit';
import 'shiki-es';
import 'unenv/runtime/npm/consola';
import 'http-graceful-shutdown';

const mail_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const transporter = nodemailer.createTransport({
    port: 465,
    host: "smtp.gmail.com",
    auth: {
      user: config.mail,
      pass: config.pwd
    },
    secure: true
    // upgrades later with STARTTLS -- change this based on the PORT
  });
  const body = await readBody(event);
  const mailData = {
    from: config.mail,
    to: config.mailTo,
    subject: "\u0417\u0430\u044F\u0432\u043A\u0430 \u0441 \u0441\u0430\u0439\u0442\u0430 9am agency",
    text: `\u0417\u0430\u044F\u0432\u043A\u0430 \u0441 \u0441\u0430\u0439\u0442\u0430! \u0418\u043C\u044F: ${body.name} \u0422\u0435\u043B\u0435\u0444\u043E\u043D: ${body.phone} \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435: ${body.message}`,
    html: `<b>\u0417\u0430\u044F\u0432\u043A\u0430 \u0441 \u0441\u0430\u0439\u0442\u0430! </b><br> \u0418\u043C\u044F: ${body.name}<br/> \u0422\u0435\u043B\u0435\u0444\u043E\u043D: ${body.phone}<br/> \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435: ${body.message}<br/>`
  };
  await transporter.sendMail(mailData);
  return { body: "ok", status: "success" };
});

export { mail_post as default };
//# sourceMappingURL=mail.post.mjs.map
